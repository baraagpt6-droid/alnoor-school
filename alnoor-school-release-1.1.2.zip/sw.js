/* مدرسة النور PWA service worker — bump CACHE_VERSION on every release. */
const CACHE_VERSION = "alnoor-school-v1.1.2";
const APP_SHELL = ["./", "./index.html", "./styles.fixed.css", "./manifest.json", "./logo.png", "./logo-192.png", "./logo-512.png", "./apple-touch-icon.png", "./curriculum.json"];
const RUNTIME_CACHE = `${CACHE_VERSION}-runtime`;

self.addEventListener("install", (event) => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE_VERSION);
    await cache.addAll(APP_SHELL.map((path) => new Request(new URL(path, self.registration.scope), { cache: "reload" })));
    await self.skipWaiting();
  })());
});

self.addEventListener("activate", (event) => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter((key) => key.startsWith("alnoor-school-") && key !== CACHE_VERSION && key !== RUNTIME_CACHE).map((key) => caches.delete(key)));
    await self.clients.claim();
  })());
});

self.addEventListener("message", (event) => {
  if (event.data && event.data.type === "SKIP_WAITING") self.skipWaiting();
});

self.addEventListener("fetch", (event) => {
  const request = event.request;
  if (request.method !== "GET") return;
  const url = new URL(request.url);

  // Local app shell: cache-first, so the installed PWA can open offline.
  if (url.origin === self.location.origin) {
    event.respondWith((async () => {
      const cache = await caches.open(CACHE_VERSION);
      const cached = await cache.match(request, { ignoreSearch: true });
      if (cached) {
        event.waitUntil(fetch(request).then((response) => {
          if (response && response.ok) cache.put(request, response.clone());
        }).catch(() => {}));
        return cached;
      }
      try {
        const response = await fetch(request);
        if (response && response.ok) await cache.put(request, response.clone());
        return response;
      } catch (error) {
        if (request.mode === "navigate") return (await cache.match(new URL("./index.html", self.registration.scope))) || Response.error();
        return Response.error();
      }
    })());
    return;
  }

  // Cache external scripts and fonts after first visit. API POST requests are never cached.
  if (/^(fonts\.googleapis\.com|fonts\.gstatic\.com|unpkg\.com|cdnjs\.cloudflare\.com)$/.test(url.hostname)) {
    event.respondWith((async () => {
      const cache = await caches.open(RUNTIME_CACHE);
      const cached = await cache.match(request);
      const network = fetch(request).then((response) => {
        if (response && (response.ok || response.type === "opaque")) cache.put(request, response.clone());
        return response;
      }).catch(() => null);
      if (cached) { event.waitUntil(network); return cached; }
      return (await network) || Response.error();
    })());
  }
});
