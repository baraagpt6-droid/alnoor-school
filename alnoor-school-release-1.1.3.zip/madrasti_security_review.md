# مراجعة أمان مشروع مدرستي — الجزء المرسل

## النتيجة العامة

الواجهة تحتوي على تصميم جيد كبداية، لكن الكود الحالي لا يوفّر حماية حسابات أو بيانات حقيقية. السبب الأكبر أن بيانات الحسابات وكلمات المرور وبيانات الطلاب موجودة داخل JavaScript الذي يصل إلى كل مستخدم. أي شخص يستطيع فتح أدوات المطور أو تنزيل ملفات الصفحة وقراءة هذه البيانات.

المقتطف المرسل ينتهي عند نهاية مكوّن `InteractiveTouchReader`. لا يحتوي على بقية التطبيق، أو نقطة تشغيل React، أو منطق تسجيل الدخول والحفظ، أو الخادم. لذلك هذه مراجعة وتعديلات للجزء الظاهر فقط، وليست شهادة بأن التطبيق الكامل أصبح آمناً. في الجزء الظاهر لا أرى استخداماً مباشراً لـ `dangerouslySetInnerHTML`؛ React يهرب النصوص المعروضة عادةً. لكن لا يمكن الحكم على بقية الصفحة قبل استلام بقية الملفات.

## الثغرات والمشكلات حسب الأولوية

| الأولوية | المشكلة | الأثر | الإجراء المطلوب |
|---|---|---|---|
| حرجة | كلمات المرور ورمز المدير موجودة في `INITIAL_DATA` | أي مستخدم يستطيع استخراج حساب المدير وحسابات الطلاب والمعلمين وأولياء الأمور | حذف كلمات المرور من الواجهة. نقل تسجيل الدخول والتحقق إلى خادم موثوق |
| حرجة | بيانات الطلاب والدرجات وأرقام أولياء الأمور ضمن ملف الواجهة | كشف بيانات شخصية وتعليمية لجميع زوار الموقع | جلب بيانات المستخدم المصرح بها فقط من API بعد التحقق من هويته وصلاحيته |
| حرجة | أي بيانات جلسة أو دور مستخدم محفوظة في `localStorage` يمكن تعديلها | يستطيع المستخدم تغيير الدور أو معرف الحساب محلياً إذا كان التطبيق يعتمد عليها للصلاحيات | لا تعتمد على `localStorage` لإثبات الهوية أو الصلاحيات. تحقّق من كل طلب في الخادم |
| عالية | وجود مفتاح `STORAGE_KEY` يوحي بحفظ نسخة كاملة من البيانات محلياً | قد تبقى الدرجات والرسائل وكلمات المرور على الجهاز أو تظهر في أدوات المطور والنسخ الاحتياطية | لا تحفظ كلمات المرور أو البيانات الحساسة في تخزين المتصفح. استخدمه فقط لتفضيلات غير حساسة |
| عالية | تحميل React وBabel وTailwind والخطوط من CDN دون تثبيت إصدارات دقيقة أو SRI | تعطل الصفحة أو تغيّر محتوى مكتبة خارجية قد يؤثر في التطبيق | استخدم build محلياً بإصدارات مثبتة. لا تستخدم Babel standalone أو Tailwind CDN في الإنتاج |
| عالية | لا تظهر في المقتطف حماية خادم أو تحديد معدل محاولات الدخول | قد تتعرض واجهة الدخول للتخمين الآلي إذا كان الخادم لا يحد المحاولات | فرض rate limiting، وتسجيل محاولات الدخول، وإبطاء المحاولات الفاشلة |
| متوسطة | `user-scalable=no` و`maximum-scale=1.0` يمنعان تكبير الصفحة | يضر بإمكانية الوصول وقراءة الصفحة | السماح بالتكبير وحذف هذه القيود |
| متوسطة | `SmartBadgeIcon` يستخدم `span` مع `onClick` | لا يعمل بلوحة المفاتيح بصورة صحيحة ولا يعلن نفسه كزر لقارئ الشاشة | استخدام `button` عند وجود إجراء، مع اسم واضح وإغلاق ripple timers |
| متوسطة | `SchoolLogoSVG` يستخدم `id="haloGrad"` ثابتاً | تكرار الشعار في الصفحة قد يسبب تعارض معرفات SVG | توليد معرف فريد لكل نسخة من الشعار |
| متوسطة | القارئ والمختبر يفترضان وصول `lesson` وبياناته سليمة | بيانات ناقصة أو تالفة قد توقف المكوّن | التحقق من بنية الدرس قبل استخدام `lesson.sentences` |
| متوسطة | أوصاف المجسمات تسميها 3D رغم أن المعروض CSS/SVG ثنائي الأبعاد | وصف غير دقيق للميزة | تسميتها «مجسم تفاعلي مبسط» أو استخدام محرك 3D حقيقي مثل Three.js |

## التغييرات الفورية

### 1. السماح بتكبير الشاشة

استبدل وسم viewport بهذا:

```html
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover" />
```

### 2. استبدال `SmartBadgeIcon`

هذه النسخة تستخدم زرّاً حقيقياً عندما يكون هناك إجراء، وتزيل مؤقتات ripple عند إزالة المكوّن:

```jsx
function SmartBadgeIcon({
  icon = "sparkles",
  active = false,
  size = "md",
  variant = "gold",
  pulse = false,
  onClick,
  label = "تنفيذ الإجراء"
}) {
  const [ripples, setRipples] = useState([]);
  const timersRef = useRef(new Set());
  const nextRippleId = useRef(0);

  useEffect(() => {
    return () => {
      timersRef.current.forEach((timer) => window.clearTimeout(timer));
      timersRef.current.clear();
    };
  }, []);

  const triggerRipple = (event) => {
    if (!onClick) return;

    const rect = event.currentTarget.getBoundingClientRect();
    const id = ++nextRippleId.current;
    setRipples((items) => [...items, { id, x: rect.width / 2, y: rect.height / 2 }]);

    const timer = window.setTimeout(() => {
      setRipples((items) => items.filter((item) => item.id !== id));
      timersRef.current.delete(timer);
    }, 600);
    timersRef.current.add(timer);

    onClick(event);
  };

  const sizeStyles = {
    sm: "w-9 h-9 rounded-xl",
    md: "w-11 h-11 rounded-2xl",
    lg: "w-14 h-14 rounded-2xl",
    xl: "w-16 h-16 rounded-3xl"
  };
  const iconSizes = {
    sm: "w-4 h-4",
    md: "w-5 h-5",
    lg: "w-7 h-7",
    xl: "w-8 h-8"
  };
  const variantStyles = {
    gold: active
      ? "bg-gradient-to-br from-[#E8C84A] to-[#C9A227] text-[#2A2118] shadow-[0_0_18px_rgba(201,162,39,0.55)] border-[#FFF3B0]"
      : "bg-[var(--surface2)] text-[var(--gold)] border-[var(--line)] hover:border-[#C9A227] hover:shadow-[0_0_12px_rgba(201,162,39,0.3)]",
    olive: active
      ? "bg-gradient-to-br from-[#7A8A44] to-[#5A6B2F] text-white shadow-[0_0_18px_rgba(90,107,47,0.5)] border-[#DCE6B8]"
      : "bg-[var(--surface2)] text-[var(--olive)] border-[var(--line)] hover:border-[#5A6B2F]",
    brown: active
      ? "bg-gradient-to-br from-[#A05A2B] to-[#8A4A22] text-[#FFF9EC] shadow-[0_0_18px_rgba(138,74,34,0.5)] border-[#E8C84A]"
      : "bg-[var(--surface2)] text-[var(--brown)] border-[var(--line)] hover:border-[#8A4A22]"
  };

  const className = `relative inline-flex items-center justify-center border transition-all duration-200 overflow-hidden select-none shrink-0 ${sizeStyles[size] || sizeStyles.md} ${variantStyles[variant] || variantStyles.gold} ${pulse ? "smart-icon-pulse" : "hover:scale-105 active:scale-95"} ${onClick ? "cursor-pointer" : "cursor-default"}`;
  const content = (
    <>
      <span className="relative z-10 flex items-center justify-center transition-transform duration-200">
        <VectorGlyph name={icon} className={iconSizes[size] || iconSizes.md} />
      </span>
      {active && (
        <span aria-hidden="true" className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-emerald-400 ring-2 ring-white/80 z-20" />
      )}
      {ripples.map((ripple) => (
        <span
          key={ripple.id}
          aria-hidden="true"
          style={{ left: ripple.x - 16, top: ripple.y - 16 }}
          className="absolute w-8 h-8 rounded-full bg-white/60 pointer-events-none ripple-effect z-0"
        />
      ))}
    </>
  );

  if (!onClick) {
    return <span className={className} aria-hidden="true">{content}</span>;
  }

  return (
    <button
      type="button"
      className={className}
      onClick={triggerRipple}
      aria-label={label}
    >
      {content}
    </button>
  );
}
```

في استخدام النطق الحالي، مرّر اسماً واضحاً:

```jsx
<SmartBadgeIcon
  icon="speaker"
  active={true}
  size="md"
  variant="brown"
  pulse={true}
  label="استمع إلى الجملة الحالية"
  onClick={() => speakArabic(currentSentence.text)}
/>
```

### 3. إصلاح معرف SVG المكرر

في بداية `SchoolLogoSVG` أضف معرفاً فريداً:

```jsx
function SchoolLogoSVG({ size = 112 }) {
  const gradientId = `haloGrad-${React.useId().replace(/:/g, "")}`;
```

ثم استبدل:

```jsx
<linearGradient id="haloGrad" ...>
```

بـ:

```jsx
<linearGradient id={gradientId} ...>
```

واستبدل:

```jsx
stroke="url(#haloGrad)"
```

بـ:

```jsx
stroke={`url(#${gradientId})`}
```

### 4. تحصين دالة النطق

استبدل `speakArabic` بهذه النسخة:

```jsx
function speakArabic(text) {
  if (typeof text !== "string" || !text.trim()) return;
  if (typeof window === "undefined" || !("speechSynthesis" in window)) return;

  try {
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text.slice(0, 4000));
    utterance.lang = "ar-SA";
    utterance.rate = 0.95;

    const chooseVoice = () => {
      const voices = window.speechSynthesis.getVoices();
      const arabicVoice = voices.find((voice) =>
        typeof voice.lang === "string" && voice.lang.toLowerCase().startsWith("ar")
      );
      if (arabicVoice) utterance.voice = arabicVoice;
    };

    chooseVoice();
    window.speechSynthesis.speak(utterance);
  } catch (error) {
    console.error("تعذر تشغيل النطق الصوتي", error);
  }
}
```

### 5. منع توقف القارئ عند وجود درس ناقص

داخل `InteractiveTouchReader`، غيّر اعتماد `useEffect` إلى `lesson?.id`، ثم تحقّق من الدرس قبل قراءة الجمل. يجب أن يبقى هذا التحقق بعد استدعاءات Hooks حتى لا يتغير ترتيبها:

```jsx
useEffect(() => {
  setActiveSentenceIdx(0);
  setSelectedWordInfo(null);
}, [lesson?.id]);

const sentences = Array.isArray(lesson?.sentences) ? lesson.sentences : [];
const currentSentence = sentences[activeSentenceIdx] || sentences[0];

if (!lesson || sentences.length === 0) {
  return (
    <div className="card p-4" role="status">
      لا تتوفر جمل لهذا الدرس حالياً.
    </div>
  );
}
```

بعد إضافة هذا الفحص، استبدل `lesson.sentences.map(...)` بـ `sentences.map(...)`، واستبدل `lesson.sentences.map((s) => s.text)` بـ `sentences.map((s) => s.text)`.

### 6. دعم تقليل الحركة

أضف إلى CSS:

```css
@media (prefers-reduced-motion: reduce) {
  *,
  *::before,
  *::after {
    scroll-behavior: auto !important;
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
  }
}
```

## تعديلات بنيوية لا يمكن تنفيذها من HTML وحده

1. أزل `pass` من كل كائن في `INITIAL_DATA`، بما في ذلك `adminAccount` و`students` و`parents` و`teachers`. لا تستبدلها بكلمات مرور مشفرة داخل JavaScript؛ أي قيمة داخل الواجهة قابلة للاستخراج.
2. انقل بيانات الحسابات والتحقق من كلمات المرور إلى خادم. خزّن كلمات المرور هناك باستخدام Argon2id مع إعدادات مناسبة.
3. اجعل الخادم يصدر جلسة داخل Cookie تحمل `HttpOnly; Secure; SameSite=Lax; Path=/`. لا تخزّن كلمة المرور أو رمز الجلسة في `localStorage`.
4. افحص صلاحية المستخدم في كل API endpoint. إخفاء زر أو صفحة في React لا يمنع الوصول المباشر إلى API.
5. ولي الأمر لا يحصل إلا على سجلات أبنائه التي يتحقق الخادم من ملكيتها. المعلم يحصل على الصفوف والمواد المصرح بها فقط. المدير يحتاج صلاحيات منفصلة مسجلة في الخادم.
6. أضف تحديد معدل لمحاولات الدخول، وقفلًا مؤقتاً بعد المحاولات الفاشلة، وسجلاً لمحاولات الدخول وتغييرات الدرجات.
7. أضف حماية CSRF عند استخدام جلسات Cookie، واستخدم HTTPS لكل الاتصالات.
8. لا تضع بيانات طلاب حقيقية في `INITIAL_DATA`. استبدلها ببيانات تجريبية غير حقيقية، واجلب البيانات الفعلية بعد تسجيل الدخول.
9. استبدل CDN في الإنتاج ببناء محلي عبر Vite أو أداة بناء مماثلة. ثبّت إصدارات React وبقية الحزم في ملف lockfile.
10. اضبط ترويسات الخادم الأمنية. ابدأ بـ `Content-Security-Policy` مناسبة لبنية النشر، و`X-Content-Type-Options: nosniff`، و`Referrer-Policy: strict-origin-when-cross-origin`، و`Strict-Transport-Security` بعد تفعيل HTTPS.

## فحوصات يجب تنفيذها بعد دمج التعديلات

- افتح الصفحة في نافذة خاصة وسجّل الدخول بحساب تجريبي.
- حاول تغيير دور المستخدم ومعرّفه في أدوات المطور. يجب أن يرفض الخادم الوصول غير المصرح به.
- حاول طلب سجل طالب آخر مباشرة من API. يجب أن يرجع الخادم 403 أو 404 دون كشف البيانات.
- غيّر محتوى `localStorage` واحذف مفاتيح التخزين. يجب ألا يمنح ذلك صلاحية دخول أو إدارة.
- أرسل قيمًا طويلة أو فارغة أو غير متوقعة في حقول الإدخال. يجب أن يتحقق الخادم منها قبل الحفظ.
- افحص عدم ظهور كلمات المرور أو أرقام الهواتف أو الدرجات الخاصة بطلاب آخرين في ملفات JavaScript أو استجابات API غير المصرح بها.
- جرّب لوحة المفاتيح وقارئ الشاشة وتكبير الصفحة وتقليل الحركة.

## ما يلزم لإتمام الإصلاح الكامل

أرسل ملف HTML كاملاً أو ملفات المشروع، بما فيها بقية مكوّنات React ومنطق تسجيل الدخول والحفظ. المقتطف الحالي لا يتضمن هذه الأجزاء؛ لذلك لا يمكن فحص مساراتها أو تعديلها أو اختبارها من النص المتاح.
